[ ] Checker no passa però format correcte
[ ] Cronometrar cada solucio
[ ] Una solució és millor si ha tardat menys?
[ ] Print dels jugadors amb el nou sistema de ID's.



[ ] Eliminar paramestres de exh amb ifs de size dels vectors players?
[ ] Funcio per la generacio de def, dav, mig?
[ ] Pot retornar una solució incompleta al arribar al maxim index?